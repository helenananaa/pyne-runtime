"""Independent audit of completed capacity cases and their raw event streams."""
import collections
import hashlib
import json
import math
import statistics
from pathlib import Path

root=Path(__file__).resolve().parent
if not __debug__: raise RuntimeError('Run the evidence audit without -O')
reports=[]
for sessions in (1,4,8):
    path=root/f'qualification.s{sessions}.json'
    if not path.exists(): continue
    case=json.loads(path.read_text())
    if not case['completed']: continue
    events_path=root/f'qualification.s{sessions}.events.jsonl'
    groups=collections.defaultdict(list)
    counts=collections.Counter()
    events_count=0
    for line in events_path.open(encoding='utf8'):
        event=json.loads(line)
        i=event['session']; bar=event['barIndex']; kind=event['kind']; ms=event['ms']
        assert 0<=i<sessions and 0<=bar<4096 and kind in ('preview','confirmed')
        assert event['workload']==case['workloads'][i]
        assert math.isfinite(ms) and ms>=0
        counts[i,bar,kind]+=1
        groups[(bar//256,kind)].append(ms)
        events_count+=1
    for i in range(sessions):
        for bar in range(4096):
            assert counts[i,bar,'preview']==4
            assert counts[i,bar,'confirmed']==1
    assert events_count==sessions*4096*5
    checks=0
    for index,window in enumerate(case['windows']):
        assert window['committedBars']==(index+1)*256
        for kind in ('preview','confirmed'):
            values=sorted(groups[index,kind]); sample=window[kind]
            expected=dict(count=len(values), medianMs=statistics.median(values),
                          p95Ms=values[math.ceil(len(values)*.95)-1], maxMs=max(values))
            assert all(sample[key]==value for key,value in expected.items()), (index,kind)
        for session in window['sessions']:
            for check in session['checks']:
                assert check['passed'] and not check.get('pending',False), check
                if check.get('applicable',True): checks+=1
    assert len(case['windows'])==16 and not case['invariantFailures']
    types={}
    for name in sorted(set(case['workloads'])):
        snapshots=[s['typedState'] for w in case['windows'] for s in w['sessions'] if s['workload']==name]
        types[name]={'snapshotBytesMin':min(x['bytes'] for x in snapshots),'snapshotBytesMax':max(x['bytes'] for x in snapshots),
                     'restoreMedianMs':statistics.median(x['restoreMs'] for x in snapshots),'restoreMaxMs':max(x['restoreMs'] for x in snapshots)}
    summaries={}
    for kind in ('preview','confirmed'):
        values=sorted(x for (window,k),series in groups.items() if k==kind for x in series)
        summaries[kind]={'medianMs':statistics.median(values),'p95Ms':values[math.ceil(len(values)*.95)-1],'maxMs':max(values)}
    reports.append({'sessions':sessions,'barsPerSession':4096,'events':events_count,'applicableChecks':checks,
                    'rssFirstMiB':case['windows'][0]['processRss']['bytes']/2**20,
                    'rssLastMiB':case['windows'][-1]['processRss']['bytes']/2**20,
                    'rssMaxMiB':max(w['processRss']['bytes'] for w in case['windows'])/2**20,
                    'cacheDropWindows':sum(s['cachePressure']['evictionObserved'] for w in case['windows'] for s in w['sessions']),
                    'snapshots':types,'timings':summaries,'rawSha256':hashlib.sha256(events_path.read_bytes()).hexdigest(),
                    'reportSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
out={'completed':len(reports)==3,'method':'independent raw-event count and window statistic recomputation; applicable invariant and pending-state inspection','cases':reports}
(root/'recomputed-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
