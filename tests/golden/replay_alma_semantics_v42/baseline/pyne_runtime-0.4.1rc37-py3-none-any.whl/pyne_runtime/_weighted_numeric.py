"""Exact bounded-width binary64 arithmetic for causal weighted calculations.

Each observation enters and leaves a rolling sum once. General fixed-weight
convolution uses integer polynomial multiplication, with byte-aligned slots wide
enough to prevent carries between coefficients. Removing common powers of two
keeps ordinary inputs small; binary64 bounds the worst-case coefficient width.
Only final results are rounded, so algorithm selection and future samples cannot
change an already calculated window.
"""
from __future__ import annotations

import math

import numpy as np


SCALE = 1 << 1074


def scaled_float(value: float) -> int:
    numerator, denominator = value.as_integer_ratio()
    return numerator << (1074 - (denominator.bit_length() - 1))


def rounded_ratio(numerator: int, denominator: int) -> float:
    try:
        return numerator / denominator
    except OverflowError:
        return math.inf if numerator > 0 else -math.inf


def weighted_windows(source: np.ndarray, period: int):
    """Yield full-window exact raw/1..period sums and finite observation counts."""
    window = [(0, False)] * period
    total = weighted = valid_count = 0
    for index, value in enumerate(source):
        number = float(value)
        valid = math.isfinite(number)
        incoming = scaled_float(number) if valid else 0
        slot = index % period
        outgoing, was_valid = window[slot]
        if index < period:
            weighted += (index + 1) * incoming
        else:
            weighted += period * incoming - total
        total += incoming - outgoing
        valid_count += int(valid) - int(was_valid)
        window[slot] = incoming, valid
        if index >= period - 1:
            yield index, total, weighted, valid_count


def _integer_coefficients(values: np.ndarray) -> tuple[list[int], int]:
    coefficients = [scaled_float(float(value)) for value in values]
    nonzero = [abs(value) for value in coefficients if value]
    shift = min((value & -value).bit_length() - 1 for value in nonzero) if nonzero else 0
    return [value >> shift for value in coefficients], shift


def _packed_polynomial(coefficients: list[int], offset: int, width: int) -> int:
    return int.from_bytes(b"".join((value + offset).to_bytes(width, "little")
        for value in coefficients), "little")


def exact_convolution(source: np.ndarray, weights: np.ndarray) -> np.ndarray:
    """Return valid correlation without a window scan or floating FFT leakage.

    Python's large-integer multiplication uses subquadratic multiplication.
    Encoding and decoding each coefficient is linear in the sample count and
    binary64 coefficient width plus the window-size carry guard. Signed inputs
    and weights use independent nonnegative offsets whose cross terms are
    removed exactly after multiplication.
    """
    values, value_shift = _integer_coefficients(source)
    kernel, kernel_shift = _integer_coefficients(weights[::-1])
    period = len(kernel)
    result = np.empty(len(values) - period + 1)
    if not any(values) or not any(kernel):
        result.fill(0.0)
        return result
    value_offset = max(-min(values, default=0), 0)
    kernel_offset = max(-min(kernel, default=0), 0)
    max_value = max(values, default=0) + value_offset
    max_kernel = max(kernel, default=0) + kernel_offset
    # Every product coefficient has at most period nonnegative terms.
    bound = period * max_value * max_kernel
    width = max((max(bound, max_value, max_kernel).bit_length() + 7) // 8, 1)
    packed = (_packed_polynomial(values, value_offset, width)
              * _packed_polynomial(kernel, kernel_offset, width))
    coefficients = memoryview(packed.to_bytes((len(values) + period - 1) * width, "little"))
    exponent = 2148 - value_shift - kernel_shift
    divisor = 1 << max(exponent, 0)
    kernel_sum = sum(kernel)
    total = sum(values[:period])
    for at in range(len(result)):
        start = (at + period - 1) * width
        coefficient = int.from_bytes(coefficients[start:start+width], "little")
        numerator = (coefficient - value_offset * kernel_sum - kernel_offset * total
                     - period * value_offset * kernel_offset)
        if exponent < 0:
            numerator <<= -exponent
        result[at] = rounded_ratio(numerator, divisor)
        if at + period < len(values):
            total += values[at+period] - values[at]
    return result
