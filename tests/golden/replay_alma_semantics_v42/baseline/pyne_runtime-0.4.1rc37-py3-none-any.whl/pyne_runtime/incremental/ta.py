"""Step-by-step technical analysis helpers for incremental sessions."""
from __future__ import annotations

import math
from collections import deque
from typing import Any

from ..ta_kernels import (
    _FLOAT_EXACT_SCALE, _FLOAT_MIN_NORMAL, _exact_stdev, _exact_variance,
    _normalize_pivot_type, _pivot_level_values, _scaled_float,
)
from ..utils import require_positive_period
from ..values import is_condition_true
from .._weighted_numeric import rounded_ratio
from ._pivot_window import _PivotWindow
from ._ta_capacity import window_capacity
from .limits import IncrementalLimits, _LimitTracker


class _StepRollingMoments:
    """Bounded present-observation window with periodically rebased moments.

    Centering avoids subtracting two price-squared values for small variance
    around large offsets. Periodic rebasing costs O(period) every at least
    period updates, so normal streaming work is amortized O(1).
    """
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.window: deque[float] = deque()
        self.anchor: float | None = None
        self.sum = 0.0
        self.sumsq = 0.0
        self.exact_sum = 0
        self.exact_sumsq: int | None = None
        self.nonzero_centered = 0
        self.positive_infinity = 0
        self.negative_infinity = 0
        self.updates = 0

    def push(self, value: Any) -> None:
        number = _number_or_none(value)
        if number is None:
            return
        if self.anchor is None and math.isfinite(number):
            self.anchor = number
        self.window.append(number)
        self._accumulate(number, 1)
        if len(self.window) > self.period:
            self._accumulate(self.window.popleft(), -1)
        self.updates += 1
        if self.updates % max(self.period, 4096) == 0:
            self._rebase()

    def _accumulate(self, number: float, sign: int) -> None:
        if number == math.inf:
            self.positive_infinity += sign
        elif number == -math.inf:
            self.negative_infinity += sign
        else:
            numerator, denominator = number.as_integer_ratio()
            scaled = numerator << (1074 - (denominator.bit_length() - 1))
            self.exact_sum += sign * scaled
            if self.exact_sumsq is not None:
                self.exact_sumsq += sign * scaled * scaled
            centered = number - (self.anchor or 0.0)
            self.nonzero_centered += sign * int(centered != 0.0)
            self.sum += sign * centered
            self.sumsq += sign * centered * centered

    def _rebase(self) -> None:
        finite = [value for value in self.window if math.isfinite(value)]
        self.anchor = finite[0] if finite else None
        centered = [value - (self.anchor or 0.0) for value in finite]
        self.sum = sum(centered)
        self.sumsq = sum(value * value for value in centered)
        self.nonzero_centered = sum(value != 0.0 for value in centered)

    def mean_value(self) -> float | None:
        if len(self.window) < self.period:
            return None
        if self.period == 1:
            return self.window[-1]
        if self.positive_infinity or self.negative_infinity:
            if self.positive_infinity and self.negative_infinity:
                return None
            return math.inf if self.positive_infinity else -math.inf
        # A stale large anchor can erase every later small observation before
        # summation. Maintain the raw finite sum exactly instead; binary64's
        # fixed exponent range bounds accumulator work independently of period.
        # Divide before rounding so a finite average survives sum overflow.
        return self.exact_sum / (_FLOAT_EXACT_SCALE * self.period)

    def variance_value(self, *, biased: bool = True) -> float | None:
        denominator = self.period if biased else self.period - 1
        if (len(self.window) < self.period or denominator <= 0
                or self.positive_infinity or self.negative_infinity):
            return None
        if self.period == 1:
            return 0.0
        if self.exact_sumsq is not None:
            return _exact_variance(self.exact_sum, self.exact_sumsq, self.period,
                                   0 if biased else 1)
        centered = self.sumsq - self.sum * self.sum / self.period
        # Rebase early after an abrupt level shift or near-total cancellation.
        if (not math.isfinite(centered) or centered < 0
                or (self.sumsq == 0.0 and self.nonzero_centered > 0)
                or (self.sumsq > 0 and centered <= 1e-10 * self.sumsq)):
            # Initialize exact squares once. Subsequent add/remove updates
            # retain O(1) work even for underflow or extreme level shifts.
            self.exact_sumsq = sum(_scaled_float(value) ** 2 for value in self.window)
            return _exact_variance(self.exact_sum, self.exact_sumsq, self.period,
                                   0 if biased else 1)
        return max(centered, 0.0) / denominator


    def stdev_value(self, *, biased: bool = True) -> float | None:
        variance = self.variance_value(biased=biased)
        if variance is None:
            return None
        if (math.isfinite(variance) and variance >= _FLOAT_MIN_NORMAL
                or variance == 0.0 and self.exact_sumsq is None and self.nonzero_centered == 0):
            return math.sqrt(variance)
        if self.exact_sumsq is None:
            self.exact_sumsq = sum(_scaled_float(value) ** 2 for value in self.window)
        return _exact_stdev(self.exact_sum, self.exact_sumsq, self.period,
                            0 if biased else 1)


class _StepSMA(_StepRollingMoments):
    def update(self, value: Any) -> float | None:
        self.push(value)
        return self.mean_value()


class _StepEMA:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.alpha = 2.0 / (self.period + 1)
        self.count = 0
        self.seed_sum = 0.0
        self.seed_count = 0
        self.ema: float | None = None

    def update(self, value: Any) -> float | None:
        number = _number_or_none(value)
        if number is None:
            return None
        if self.ema is not None:
            self.ema = self.alpha * number + (1 - self.alpha) * self.ema
            return self.ema

        self.count += 1
        self.seed_sum += number
        self.seed_count += 1
        if self.seed_count < self.period:
            return None
        self.ema = self.seed_sum / self.seed_count
        return self.ema


class _StepRMA:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.alpha = 1.0 / self.period
        self.seed_sum = 0.0
        self.seed_count = 0
        self.value: float | None = None

    def update(self, value: Any, *, emit_missing: bool = True) -> float | None:
        number = _number_or_none(value)
        if number is None:
            # A missing observation does not advance the accumulator, but the
            # public RMA output at this position is missing too.
            return None if emit_missing else self.value
        if self.value is None:
            self.seed_sum += number
            self.seed_count += 1
            if self.seed_count < self.period:
                return None
            self.value = self.seed_sum / self.period
            return self.value
        self.value = self.alpha * number + (1.0 - self.alpha) * self.value
        return self.value


class _StepWMA:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.window: deque[float | None] = deque()
        self.simple_sum = 0
        self.weighted_sum = 0
        self.positive_infinity = 0
        self.negative_infinity = 0
        self.valid_count = 0
        self.observations = 0
        self.last_input: float | None = None
        self.denominator = self.period * (self.period + 1) // 2

    def update(self, value: Any) -> float | None:
        number = _number_or_none(value)
        # Native Pine requires real observations for warmup, then advances
        # the weighted bar window using the last input during missing bars.
        missing = number is None
        if missing:
            number = self.last_input
        else:
            self.last_input = number
            self.observations = min(self.observations + 1, self.period)
        if number is None:
            return None
        numeric = _scaled_float(number) if math.isfinite(number) else 0
        next_weight = min(len(self.window) + 1, self.period)
        if len(self.window) == self.period:
            self.weighted_sum -= self.simple_sum
            removed = self.window.popleft()
            self.simple_sum -= _scaled_float(removed) if math.isfinite(removed) else 0
            self.positive_infinity -= int(removed == math.inf)
            self.negative_infinity -= int(removed == -math.inf)
        self.window.append(number)
        self.simple_sum += numeric
        self.weighted_sum += next_weight * numeric
        self.positive_infinity += int(number == math.inf)
        self.negative_infinity += int(number == -math.inf)
        self.valid_count = len(self.window)
        if missing or self.observations < self.period:
            return None
        if self.positive_infinity or self.negative_infinity:
            if self.positive_infinity and self.negative_infinity:
                return None
            return math.inf if self.positive_infinity else -math.inf
        return rounded_ratio(self.weighted_sum, _FLOAT_EXACT_SCALE * self.denominator)


class _StepVWMA:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.products: deque[float] = deque()
        self.weights: deque[float] = deque()
        self.numerator = 0
        self.denominator = 0
        self.product_positive_infinity = self.product_negative_infinity = 0
        self.weight_positive_infinity = self.weight_negative_infinity = 0

    def update(self, value: Any, volume: Any) -> float | None:
        number = _number_or_none(value)
        weight = _number_or_none(volume)
        if number is not None and weight is not None:
            product = number * weight
            if not math.isnan(product):
                self.products.append(product)
                self.numerator += _scaled_float(product) if math.isfinite(product) else 0
                self.product_positive_infinity += int(product == math.inf)
                self.product_negative_infinity += int(product == -math.inf)
                if len(self.products) > self.period:
                    removed = self.products.popleft()
                    self.numerator -= _scaled_float(removed) if math.isfinite(removed) else 0
                    self.product_positive_infinity -= int(removed == math.inf)
                    self.product_negative_infinity -= int(removed == -math.inf)
        if weight is not None:
            self.weights.append(weight)
            self.denominator += _scaled_float(weight) if math.isfinite(weight) else 0
            self.weight_positive_infinity += int(weight == math.inf)
            self.weight_negative_infinity += int(weight == -math.inf)
            if len(self.weights) > self.period:
                removed = self.weights.popleft()
                self.denominator -= _scaled_float(removed) if math.isfinite(removed) else 0
                self.weight_positive_infinity -= int(removed == math.inf)
                self.weight_negative_infinity -= int(removed == -math.inf)
        if len(self.products) < self.period or len(self.weights) < self.period:
            return None
        denominator = (math.nan if self.weight_positive_infinity and self.weight_negative_infinity
                       else math.inf if self.weight_positive_infinity
                       else -math.inf if self.weight_negative_infinity
                       else rounded_ratio(self.denominator, _FLOAT_EXACT_SCALE))
        if not denominator > 0.0:
            return None
        # Match batch's independent windows and its once-rounded rolling sums;
        # exact retained state permits recovery even when a previous sum overflowed.
        numerator = (math.nan if self.product_positive_infinity and self.product_negative_infinity
                     else math.inf if self.product_positive_infinity
                     else -math.inf if self.product_negative_infinity
                     else rounded_ratio(self.numerator, _FLOAT_EXACT_SCALE))
        return numerator / denominator


class _StepVariance(_StepRollingMoments):
    def __init__(self, period: int, *, biased: bool = True) -> None:
        super().__init__(period)
        self.biased = bool(biased)

    def update(self, value: Any) -> float | None:
        self.push(value)
        return self.variance_value(biased=self.biased)


class _StepStdev(_StepVariance):
    def update(self, value: Any) -> float | None:
        self.push(value)
        return self.stdev_value(biased=self.biased)


class _StepChange:
    def __init__(self, period: int = 1) -> None:
        self.period = require_positive_period(period)
        self.window: deque[float | None] = deque(maxlen=self.period + 1)

    def update(self, value: Any) -> float | None:
        current = _number_or_none(value)
        self.window.append(current)
        if len(self.window) <= self.period:
            return None
        previous = self.window[0]
        return None if current is None or previous is None else current - previous


class _StepExtremeBars:
    def __init__(self, period: int, *, highest: bool) -> None:
        self.period = max(int(period), 1)
        self.highest = bool(highest)
        self.index = -1
        self.window: deque[tuple[int, float]] = deque()

    def update(self, value: Any) -> float | None:
        self.index += 1
        expiry = self.index - self.period
        while self.window and self.window[0][0] <= expiry:
            self.window.popleft()
        current = _number_or_none(value)
        if current is None:
            self.window.clear()
            return 0.0 if self.index + 1 >= self.period else None
        if current is not None:
            if self.highest:
                while self.window and self.window[-1][1] < current:
                    self.window.pop()
            else:
                while self.window and self.window[-1][1] > current:
                    self.window.pop()
            self.window.append((self.index, current))
        if self.index + 1 < self.period:
            return None
        return None if not self.window else float(self.window[0][0] - self.index)


class _StepPivot(_PivotWindow):
    """Normalize inputs while preserving the registered incremental state type."""

    def update(self, value: Any) -> float | None:
        return super().update(_number_or_none(value))


class _StepTrueRange:
    def __init__(self) -> None:
        self.previous_close: float | None = None

    def update(self, bar_or_high: Any, low: Any = None, close: Any = None) -> float | None:
        if low is None and close is None:
            high = _number_or_none(getattr(bar_or_high, "high"))
            low_value = _number_or_none(getattr(bar_or_high, "low"))
            close_value = _number_or_none(getattr(bar_or_high, "close"))
        else:
            high = _number_or_none(bar_or_high)
            low_value = _number_or_none(low)
            close_value = _number_or_none(close)
        if high is None or low_value is None:
            result = None
        elif self.previous_close is None:
            result = high - low_value
        else:
            result = max(
                high - low_value,
                abs(high - self.previous_close),
                abs(low_value - self.previous_close),
            )
        self.previous_close = close_value
        return result


class _StepCum:
    def __init__(self) -> None:
        self.total = 0.0

    def update(self, value: Any) -> float | None:
        current = _number_or_none(value)
        if current is None:
            return None
        self.total += current
        return self.total


class _StepSWMA:
    def __init__(self) -> None:
        self.window: deque[float | None] = deque(maxlen=4)

    def update(self, value: Any) -> float | None:
        self.window.append(_number_or_none(value))
        if len(self.window) < 4 or any(item is None for item in self.window):
            return None
        a, b, c, d = self.window
        return (float(a) + 2.0 * float(b) + 2.0 * float(c) + float(d)) / 6.0


class _StepALMA:
    def __init__(self, period: int, offset: float = 0.85, sigma: float = 6.0) -> None:
        self.period = max(int(period), 1)
        if float(sigma) == 0.0:
            raise ValueError("ctx.ta.alma() sigma must be non-zero")
        midpoint = float(offset) * (self.period - 1)
        width = self.period / float(sigma)
        raw = [math.exp(-((index - midpoint) ** 2) / (2.0 * width * width)) for index in range(self.period)]
        total = sum(raw)
        self.weights = tuple(weight / total for weight in raw)
        self.window: deque[float | None] = deque(maxlen=self.period)

    def update(self, value: Any) -> float | None:
        self.window.append(_number_or_none(value))
        if len(self.window) < self.period or any(item is None for item in self.window):
            return None
        return sum(float(item) * weight for item, weight in zip(self.window, self.weights))


class _StepDev:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.window: deque[float | None] = deque(maxlen=self.period)

    def update(self, value: Any) -> float | None:
        self.window.append(_number_or_none(value))
        if len(self.window) < self.period or any(item is None for item in self.window):
            return None
        values = [float(item) for item in self.window]
        mean = sum(values) / self.period
        return sum(abs(item - mean) for item in values) / self.period


class _StepBOLL(_StepRollingMoments):
    def __init__(self, period: int, multiplier: float = 2.0) -> None:
        super().__init__(period)
        self.multiplier = float(multiplier)

    def update(self, value: Any) -> tuple[float | None, float | None, float | None]:
        self.push(value)
        std = self.stdev_value()
        mid = self.mean_value()
        if std is None or mid is None:
            return None, None, None
        return mid + self.multiplier * std, mid, mid - self.multiplier * std


class _StepBB(_StepBOLL):
    def update(self, value: Any) -> tuple[float | None, float | None, float | None]:
        upper, middle, lower = super().update(value)
        return middle, upper, lower


class _StepMACD:
    def __init__(self, fast: int = 12, slow: int = 26, signal: int = 9) -> None:
        self.fast = _StepEMA(max(int(fast), 1))
        self.slow = _StepEMA(max(int(slow), 1))
        self.signal = _StepEMA(max(int(signal), 1))

    def update(self, value: Any) -> tuple[float | None, float | None, float | None]:
        fast_value = self.fast.update(value)
        slow_value = self.slow.update(value)
        if fast_value is None or slow_value is None:
            return None, None, None
        dif = fast_value - slow_value
        dea = self.signal.update(dif)
        hist = dif - dea if dea is not None else None
        return dif, dea, hist


class _StepRSI:
    def __init__(self, period: int = 14) -> None:
        self.period = max(int(period), 1)
        self.prev: float | None = None
        self.count = 0
        self.gain_sum = 0.0
        self.loss_sum = 0.0
        self.avg_gain: float | None = None
        self.avg_loss: float | None = None

    def update(self, value: Any) -> float | None:
        current = _number_or_none(value)
        if current is None:
            self.prev = None
            return None
        if self.prev is None:
            self.prev = current
            return None
        delta = current - self.prev
        self.prev = current
        gain = max(delta, 0.0)
        loss = max(-delta, 0.0)
        if self.avg_gain is None or self.avg_loss is None:
            self.count += 1
            self.gain_sum += gain
            self.loss_sum += loss
            if self.count < self.period:
                return None
            self.avg_gain = self.gain_sum / self.period
            self.avg_loss = self.loss_sum / self.period
        else:
            self.avg_gain = (self.avg_gain * (self.period - 1) + gain) / self.period
            self.avg_loss = (self.avg_loss * (self.period - 1) + loss) / self.period
        return _rsi_from_avgs(self.avg_gain, self.avg_loss)

    def _current_value(self) -> float | None:
        if self.avg_gain is None or self.avg_loss is None:
            return None
        return _rsi_from_avgs(self.avg_gain, self.avg_loss)


class _StepATR:
    def __init__(self, period: int = 14, *, handle_na: bool = True) -> None:
        self.period = max(int(period), 1)
        self.handle_na = handle_na
        self.prev_close: float | None = None
        self.count = 0
        self.tr_sum = 0.0
        self.atr: float | None = None

    def update(self, bar_or_high: Any, low: Any = None, close: Any = None) -> float | None:
        if low is None and close is None:
            high = _number_or_none(getattr(bar_or_high, "high"))
            low = _number_or_none(getattr(bar_or_high, "low"))
            close = _number_or_none(getattr(bar_or_high, "close"))
        else:
            high = _number_or_none(bar_or_high)
            low = _number_or_none(low)
            close = _number_or_none(close)

        if high is None or low is None:
            self.prev_close = close
            return self.atr

        if self.prev_close is None and not self.handle_na:
            self.prev_close = close
            return self.atr
        if self.prev_close is None:
            tr = high - low
        else:
            tr = max(high - low, abs(high - self.prev_close), abs(low - self.prev_close))
        self.prev_close = close

        if self.atr is None:
            self.count += 1
            self.tr_sum += tr
            if self.count < self.period:
                return None
            self.atr = self.tr_sum / self.period
        else:
            self.atr = (self.atr * (self.period - 1) + tr) / self.period
        return self.atr


class _StepMonotonic:
    def __init__(self, period: int, *, highest: bool) -> None:
        self.period = max(int(period), 1)
        self.highest = highest
        self.index = -1
        self.window: deque[tuple[int, float]] = deque()

    def update(self, value: Any) -> float | None:
        self.index += 1
        expiry = self.index - self.period
        while self.window and self.window[0][0] <= expiry:
            self.window.popleft()
        number = _number_or_none(value)
        if number is None:
            self.window.clear()
            return None
        if number is not None:
            if self.highest:
                while self.window and self.window[-1][1] <= number:
                    self.window.pop()
            else:
                while self.window and self.window[-1][1] >= number:
                    self.window.pop()
            self.window.append((self.index, number))
        if self.index + 1 < self.period:
            return None
        return self.window[0][1] if self.window else None


class _StepStoch:
    def __init__(self, period: int) -> None:
        self.highest = _StepMonotonic(period, highest=True)
        self.lowest = _StepMonotonic(period, highest=False)
        self.last_value: float | None = None

    def update(self, source: Any, high: Any, low: Any) -> float | None:
        current = _number_or_none(source)
        highest = self.highest.update(high)
        lowest = self.lowest.update(low)
        if current is None or highest is None or lowest is None:
            return self.last_value
        spread = highest - lowest
        if spread != 0.0:
            self.last_value = 100.0 * (current - lowest) / spread
        return self.last_value


class _StepCCI:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.window: deque[float | None] = deque()

    def update(self, source: Any) -> float | None:
        current = _number_or_none(source)
        self.window.append(current)
        if len(self.window) > self.period:
            self.window.popleft()
        if len(self.window) < self.period or any(value is None for value in self.window):
            return None
        values = [float(value) for value in self.window if value is not None]
        average = sum(values) / self.period
        deviation = sum(abs(value - average) for value in values) / self.period
        if deviation == 0.0:
            return 0.0
        return (float(current) - average) / (0.015 * deviation)


class _StepHMA:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.fast = _StepWMA(max(int(self.period / 2), 1))
        self.slow = _StepWMA(self.period)
        self.result = _StepWMA(max(int(math.sqrt(self.period)), 1))

    def update(self, value: Any) -> float | None:
        fast = self.fast.update(value)
        slow = self.slow.update(value)
        combined = None if fast is None or slow is None else 2.0 * fast - slow
        return self.result.update(combined)


class _StepBarsSince:
    def __init__(self) -> None:
        self.index = -1
        self.last_true: int | None = None

    def update(self, condition: Any) -> float | None:
        self.index += 1
        if is_condition_true(condition):
            self.last_true = self.index
        return None if self.last_true is None else float(self.index - self.last_true)


class _StepValueWhen:
    def __init__(self, occurrence: int = 0) -> None:
        self.occurrence = max(int(occurrence), 0)
        self.values: deque[Any] = deque(maxlen=self.occurrence + 1)

    def update(self, condition: Any, value: Any) -> Any:
        if is_condition_true(condition):
            self.values.append(value)
        if len(self.values) <= self.occurrence:
            return None
        return self.values[-(self.occurrence + 1)]


class _StepCross:
    def __init__(self, direction: str) -> None:
        self.direction = direction
        self.previous_a: float | None = None
        self.previous_b: float | None = None

    def update(self, a: Any, b: Any) -> bool:
        current_a = _number_or_none(a)
        current_b = _number_or_none(b)
        crossed = False
        if (
            current_a is not None
            and current_b is not None
            and self.previous_a is not None
            and self.previous_b is not None
        ):
            over = current_a > current_b and self.previous_a <= self.previous_b
            under = current_a < current_b and self.previous_a >= self.previous_b
            strict = (current_a > current_b and self.previous_a < self.previous_b) or (
                current_a < current_b and self.previous_a > self.previous_b)
            crossed = over if self.direction == "over" else under if self.direction == "under" else strict
        if current_a is not None and current_b is not None:
            self.previous_a = current_a
            self.previous_b = current_b
        return crossed


class _StepVWAP:
    def __init__(self) -> None:
        self.running = False
        self.volume_sum = 0.0
        self.weighted_sum = 0.0
        self.weighted_square_sum = 0.0

    def update(
        self,
        source: Any,
        volume: Any,
        *,
        anchor: Any = False,
        stdev_mult: Any = None,
    ) -> float | None | tuple[float | None, float | None, float | None]:
        if bool(anchor):
            self.running = True
            self.volume_sum = 0.0
            self.weighted_sum = 0.0
            self.weighted_square_sum = 0.0
        if not self.running:
            empty = None
            return (empty, empty, empty) if stdev_mult is not None else empty
        price = _number_or_none(source)
        weight = _number_or_none(volume)
        if price is not None and weight is not None:
            self.volume_sum += weight
            self.weighted_sum += price * weight
            self.weighted_square_sum += price * price * weight
        if self.volume_sum == 0.0:
            empty = None
            return (empty, empty, empty) if stdev_mult is not None else empty
        value = self.weighted_sum / self.volume_sum
        if stdev_mult is None:
            return value
        multiplier = _number_or_none(stdev_mult)
        if multiplier is None:
            return value, None, None
        variance = max(self.weighted_square_sum / self.volume_sum - value * value, 0.0)
        deviation = math.sqrt(variance) * multiplier
        return value, value + deviation, value - deviation


class _StepDMI:
    def __init__(self, period: int = 14, adx_period: int = 14) -> None:
        self.atr = _StepATR(period, handle_na=False)
        self.plus = _StepRMA(period)
        self.minus = _StepRMA(period)
        self.adx = _StepRMA(adx_period)
        self.previous_high: float | None = None
        self.previous_low: float | None = None
        self.last_plus_di: float | None = None
        self.last_minus_di: float | None = None

    def update(
        self,
        bar_or_high: Any,
        low: Any = None,
        close: Any = None,
    ) -> tuple[float | None, float | None, float | None]:
        if low is None and close is None:
            high = _number_or_none(getattr(bar_or_high, "high"))
            low_value = _number_or_none(getattr(bar_or_high, "low"))
            close_value = _number_or_none(getattr(bar_or_high, "close"))
        else:
            high = _number_or_none(bar_or_high)
            low_value = _number_or_none(low)
            close_value = _number_or_none(close)
        if high is None or low_value is None:
            atr = self.atr.update(high, low_value, close_value)
            return self.last_plus_di, self.last_minus_di, self.adx.update(None, emit_missing=False)
        up_move = None if self.previous_high is None else high - self.previous_high
        down_move = None if self.previous_low is None else self.previous_low - low_value
        plus_dm = (
            None
            if up_move is None or down_move is None
            else up_move
            if up_move > down_move and up_move > 0.0
            else 0.0
        )
        minus_dm = (
            None
            if up_move is None or down_move is None
            else down_move
            if down_move > up_move and down_move > 0.0
            else 0.0
        )
        self.previous_high = high
        self.previous_low = low_value
        atr = self.atr.update(high, low_value, close_value)
        plus_smoothed = self.plus.update(plus_dm, emit_missing=False)
        minus_smoothed = self.minus.update(minus_dm, emit_missing=False)
        if atr not in {None, 0.0} and plus_smoothed is not None:
            self.last_plus_di = 100.0 * plus_smoothed / atr
        if atr not in {None, 0.0} and minus_smoothed is not None:
            self.last_minus_di = 100.0 * minus_smoothed / atr
        dx = None
        if self.last_plus_di is not None and self.last_minus_di is not None:
            total = self.last_plus_di + self.last_minus_di
            dx = abs(self.last_plus_di - self.last_minus_di) / (1.0 if total == 0.0 else total)
        adx = self.adx.update(dx, emit_missing=False)
        return self.last_plus_di, self.last_minus_di, None if adx is None else 100.0 * adx


class _StepADX(_StepDMI):
    def update(self, bar_or_high: Any, low: Any = None, close: Any = None) -> float | None:
        return super().update(bar_or_high, low, close)[2]


class _StepSAR:
    def __init__(self, start: float, increment: float, maximum: float) -> None:
        self.start = float(start)
        self.increment = float(increment)
        self.maximum = float(maximum)
        self.index = -1
        self.sar: float | None = None
        self.extreme: float | None = None
        self.acceleration: float | None = None
        self.is_below = False
        self.previous_close: float | None = None
        self.previous_highs: deque[float | None] = deque(maxlen=2)
        self.previous_lows: deque[float | None] = deque(maxlen=2)

    def update(self, bar_or_high: Any, low: Any = None, close: Any = None) -> float | None:
        if low is None and close is None:
            high = _number_or_none(getattr(bar_or_high, "high"))
            low_value = _number_or_none(getattr(bar_or_high, "low"))
            close_value = _number_or_none(getattr(bar_or_high, "close"))
        else:
            high = _number_or_none(bar_or_high)
            low_value = _number_or_none(low)
            close_value = _number_or_none(close)
        self.index += 1
        if high is None or low_value is None or close_value is None:
            self.sar = None
            self.extreme = None
            self.acceleration = None
            self.previous_close = close_value
            self.previous_highs.append(high)
            self.previous_lows.append(low_value)
            return None
        first_trend_bar = False
        if self.sar is None and self.previous_close is not None and self.previous_highs and self.previous_lows:
            if close_value > self.previous_close:
                self.is_below = True
                self.extreme = high
                self.sar = self.previous_lows[-1]
            else:
                self.is_below = False
                self.extreme = low_value
                self.sar = self.previous_highs[-1]
            first_trend_bar = True
            self.acceleration = self.start
        elif self.sar is not None and self.extreme is not None and self.acceleration is not None:
            self.sar = self.sar + self.acceleration * (self.extreme - self.sar)
            if self.is_below and self.sar > low_value:
                first_trend_bar = True
                self.is_below = False
                self.sar = max(high, self.extreme)
                self.extreme = low_value
                self.acceleration = self.start
            elif not self.is_below and self.sar < high:
                first_trend_bar = True
                self.is_below = True
                self.sar = min(low_value, self.extreme)
                self.extreme = high
                self.acceleration = self.start
            if not first_trend_bar:
                if self.is_below and high > self.extreme:
                    self.extreme = high
                    self.acceleration = min(self.acceleration + self.increment, self.maximum)
                elif not self.is_below and low_value < self.extreme:
                    self.extreme = low_value
                    self.acceleration = min(self.acceleration + self.increment, self.maximum)
            if self.is_below:
                for previous in self.previous_lows:
                    if previous is not None:
                        self.sar = min(self.sar, previous)
            else:
                for previous in self.previous_highs:
                    if previous is not None:
                        self.sar = max(self.sar, previous)
        result = self.sar
        self.previous_close = close_value
        self.previous_highs.append(high)
        self.previous_lows.append(low_value)
        return result


class _StepMFI:
    def __init__(self, period: int) -> None:
        self.period = max(int(period), 1)
        self.previous_source: float | None = None
        self.positive: deque[float] = deque()
        self.negative: deque[float] = deque()
        self.positive_sum = 0.0
        self.negative_sum = 0.0

    def update(self, source: Any, volume: Any) -> float | None:
        price = _number_or_none(source)
        weight = _number_or_none(volume)
        raw = None if price is None or weight is None else _number_or_none(price * weight)
        positive = raw if self.previous_source is not None and price is not None and price > self.previous_source else 0.0
        negative = raw if self.previous_source is not None and price is not None and price < self.previous_source else 0.0
        self.previous_source = price
        # Batch math.sum() has independent present-observation windows for
        # positive and negative flows. A missing active flow does not insert a
        # zero or evict the previous observation from that accumulator.
        if positive is not None:
            self.positive.append(positive)
            self.positive_sum += positive
            if len(self.positive) > self.period:
                self.positive_sum -= self.positive.popleft()
            if not math.isfinite(self.positive_sum):
                self.positive_sum = sum(self.positive)
        if negative is not None:
            self.negative.append(negative)
            self.negative_sum += negative
            if len(self.negative) > self.period:
                self.negative_sum -= self.negative.popleft()
            if not math.isfinite(self.negative_sum):
                self.negative_sum = sum(self.negative)
        if len(self.negative) < self.period:
            return 100.0
        if self.negative_sum == 0.0 or math.isnan(self.negative_sum):
            return 100.0
        if len(self.positive) < self.period:
            return None
        return 100.0 - 100.0 / (1.0 + self.positive_sum / self.negative_sum)


class _StepSupertrend:
    def __init__(self, factor: float, atr_period: int) -> None:
        self.factor = float(factor)
        self.atr = _StepATR(atr_period)
        self.previous_atr: float | None = None
        self.previous_close: float | None = None
        self.previous_upper = 0.0
        self.previous_lower = 0.0
        self.previous_supertrend: float | None = 0.0
        self.index = -1

    def update(
        self,
        bar_or_high: Any,
        low: Any = None,
        close: Any = None,
    ) -> tuple[float | None, float | None]:
        if low is None and close is None:
            high = _number_or_none(getattr(bar_or_high, "high"))
            low_value = _number_or_none(getattr(bar_or_high, "low"))
            close_value = _number_or_none(getattr(bar_or_high, "close"))
        else:
            high = _number_or_none(bar_or_high)
            low_value = _number_or_none(low)
            close_value = _number_or_none(close)
        self.index += 1
        atr = self.atr.update(high, low_value, close_value)
        if high is None or low_value is None or close_value is None or atr is None:
            self.previous_atr = atr
            self.previous_close = close_value
            self.previous_upper = 0.0
            self.previous_lower = 0.0
            return (0.0 if self.index == 0 else None), 1.0

        midpoint = (high + low_value) / 2.0
        upper = midpoint + self.factor * atr
        lower = midpoint - self.factor * atr
        previous_close = self.previous_close
        if not (
            lower > self.previous_lower
            or (previous_close is not None and previous_close < self.previous_lower)
        ):
            lower = self.previous_lower
        if not (
            upper < self.previous_upper
            or (previous_close is not None and previous_close > self.previous_upper)
        ):
            upper = self.previous_upper

        if self.index == 0 or self.previous_atr is None:
            direction = 1.0
        elif self.previous_supertrend == self.previous_upper:
            direction = -1.0 if close_value > upper else 1.0
        else:
            direction = 1.0 if close_value < lower else -1.0
        supertrend = lower if direction == -1.0 else upper

        self.previous_atr = atr
        self.previous_close = close_value
        self.previous_upper = upper
        self.previous_lower = lower
        self.previous_supertrend = supertrend
        return supertrend, direction


class _StepPivotPointLevels:
    def __init__(self, pivot_type: str = "traditional", *, developing: bool = False) -> None:
        self.pivot_type = _normalize_pivot_type(pivot_type)
        self.developing = bool(developing)
        if self.pivot_type == "woodie" and self.developing:
            raise ValueError(
                "ctx.ta.pivot_point_levels() does not allow developing=True with Woodie"
            )
        self.fixed_levels = tuple([None] * 11)
        self.period_open: float | None = None
        self.period_high: float | None = None
        self.period_low: float | None = None
        self.period_close: float | None = None

    def update(
        self,
        bar: Any,
        *,
        anchor: Any = False,
        developing: bool | None = None,
        pivot_type: str | None = None,
    ) -> tuple[float | None, ...]:
        selected_type = self.pivot_type if pivot_type is None else _normalize_pivot_type(pivot_type)
        selected_developing = self.developing if developing is None else bool(developing)
        if selected_type == "woodie" and selected_developing:
            raise ValueError(
                "ctx.ta.pivot_point_levels() does not allow developing=True with Woodie"
            )
        current_open = _number_or_none(getattr(bar, "open"))
        high = _number_or_none(getattr(bar, "high"))
        low = _number_or_none(getattr(bar, "low"))
        close = _number_or_none(getattr(bar, "close"))

        if bool(anchor):
            if self.period_open is not None:
                self.fixed_levels = _optional_levels(
                    _pivot_level_values(
                        selected_type,
                        period_open=_nan(self.period_open),
                        period_high=_nan(self.period_high),
                        period_low=_nan(self.period_low),
                        period_close=_nan(self.period_close),
                        current_open=_nan(current_open),
                    )
                )
            else:
                self.fixed_levels = tuple([None] * 11)
            self.period_open = None
            self.period_high = None
            self.period_low = None
            self.period_close = None

        if self.period_open is None:
            self.period_open = current_open
        if high is not None:
            self.period_high = high if self.period_high is None else max(self.period_high, high)
        if low is not None:
            self.period_low = low if self.period_low is None else min(self.period_low, low)
        if close is not None:
            self.period_close = close

        if not selected_developing:
            return self.fixed_levels
        return _optional_levels(
            _pivot_level_values(
                selected_type,
                period_open=_nan(self.period_open),
                period_high=_nan(self.period_high),
                period_low=_nan(self.period_low),
                period_close=_nan(self.period_close),
                current_open=_nan(current_open),
            )
        )


class IncrementalTaNamespace:
    """Stateful TA helper namespace available as ``ctx.ta``."""

    def __init__(self, limits: _LimitTracker | None = None) -> None:
        self._helpers: dict[str, Any] = {}
        self._limits = limits or _LimitTracker(IncrementalLimits(enabled=False))

    @property
    def _capacity_types(self) -> dict[str, type]:
        return {name: value for name, value in globals().items()
                if name.startswith("_Step") and isinstance(value, type)}

    def sma(self, name: str, period: int | None = None) -> _StepSMA:
        key = f"sma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.sma('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepSMA(period)
        return self._helpers[key]

    def ema(self, name: str, period: int | None = None) -> _StepEMA:
        key = f"ema:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.ema('{name}') has not been initialized")
            self._helpers[key] = _StepEMA(period)
        return self._helpers[key]

    def rma(self, name: str, period: int | None = None) -> _StepRMA:
        key = f"rma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.rma('{name}') has not been initialized")
            self._helpers[key] = _StepRMA(period)
        return self._helpers[key]

    def wma(self, name: str, period: int | None = None) -> _StepWMA:
        key = f"wma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.wma('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepWMA(period)
        return self._helpers[key]

    def vwma(self, name: str, period: int | None = None) -> _StepVWMA:
        key = f"vwma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.vwma('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepVWMA(period)
        return self._helpers[key]

    def variance(
        self,
        name: str,
        period: int | None = None,
        *,
        biased: bool = True,
    ) -> _StepVariance:
        key = f"variance:{name}:{int(bool(biased))}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.variance('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepVariance(period, biased=biased)
        return self._helpers[key]

    def stdev(self, name: str, period: int | None = None) -> _StepStdev:
        key = f"stdev:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.stdev('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepStdev(period)
        return self._helpers[key]

    def change(self, name: str, period: int | None = None) -> _StepChange:
        key = f"change:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.change('{name}') has not been initialized")
            period = require_positive_period(period)
            self._limits.reserve_window(window_capacity("change", period=period), label=key)
            self._helpers[key] = _StepChange(period)
        return self._helpers[key]

    def highestbars(self, name: str, period: int | None = None) -> _StepExtremeBars:
        return self._extreme_bars(name, period, highest=True)

    def lowestbars(self, name: str, period: int | None = None) -> _StepExtremeBars:
        return self._extreme_bars(name, period, highest=False)

    def _extreme_bars(
        self,
        name: str,
        period: int | None,
        *,
        highest: bool,
    ) -> _StepExtremeBars:
        family = "highestbars" if highest else "lowestbars"
        key = f"{family}:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.{family}('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepExtremeBars(period, highest=highest)
        return self._helpers[key]

    def pivothigh(
        self,
        name: str,
        left: int | None = None,
        right: int | None = None,
    ) -> _StepPivot:
        return self._pivot(name, left, right, highest=True)

    def pivotlow(
        self,
        name: str,
        left: int | None = None,
        right: int | None = None,
    ) -> _StepPivot:
        return self._pivot(name, left, right, highest=False)

    def _pivot(
        self,
        name: str,
        left: int | None,
        right: int | None,
        *,
        highest: bool,
    ) -> _StepPivot:
        family = "pivothigh" if highest else "pivotlow"
        key = f"{family}:{name}"
        if key not in self._helpers:
            if left is None:
                raise ValueError(f"ctx.ta.{family}('{name}') has not been initialized")
            selected_right = int(left) if right is None else int(right)
            self._limits.reserve_window(window_capacity("pivot", left=left, right=selected_right), label=key)
            self._helpers[key] = _StepPivot(left, selected_right, highest=highest)
        return self._helpers[key]

    def tr(self, name: str) -> _StepTrueRange:
        key = f"tr:{name}"
        if key not in self._helpers:
            self._helpers[key] = _StepTrueRange()
        return self._helpers[key]

    def cum(self, name: str) -> _StepCum:
        key = f"cum:{name}"
        if key not in self._helpers:
            self._helpers[key] = _StepCum()
        return self._helpers[key]

    def swma(self, name: str) -> _StepSWMA:
        key = f"swma:{name}"
        if key not in self._helpers:
            self._limits.reserve_window(4, label=key)
            self._helpers[key] = _StepSWMA()
        return self._helpers[key]

    def alma(
        self,
        name: str,
        period: int | None = None,
        offset: float = 0.85,
        sigma: float = 6.0,
    ) -> _StepALMA:
        key = f"alma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.alma('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepALMA(period, offset, sigma)
        return self._helpers[key]

    def dev(self, name: str, period: int | None = None) -> _StepDev:
        key = f"dev:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.dev('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepDev(period)
        return self._helpers[key]

    def boll(self, name: str, period: int | None = None, multiplier: float = 2.0) -> _StepBOLL:
        key = f"boll:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.boll('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepBOLL(period, multiplier)
        return self._helpers[key]

    def bb(self, name: str, period: int | None = None, mult: float = 2.0) -> _StepBB:
        key = f"bb:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.bb('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepBB(period, mult)
        return self._helpers[key]

    def macd(
        self,
        name: str,
        fast: int | None = None,
        slow: int = 26,
        signal: int = 9,
    ) -> _StepMACD:
        key = f"macd:{name}"
        if key not in self._helpers:
            if fast is None:
                raise ValueError(f"ctx.ta.macd('{name}') has not been initialized")
            self._helpers[key] = _StepMACD(fast, slow, signal)
        return self._helpers[key]

    def rsi(self, name: str, period: int | None = None) -> _StepRSI:
        key = f"rsi:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.rsi('{name}') has not been initialized")
            self._helpers[key] = _StepRSI(period)
        return self._helpers[key]

    def atr(self, name: str, period: int | None = None) -> _StepATR:
        key = f"atr:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.atr('{name}') has not been initialized")
            self._helpers[key] = _StepATR(period)
        return self._helpers[key]

    def highest(self, name: str, period: int | None = None) -> _StepMonotonic:
        key = f"highest:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.highest('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepMonotonic(period, highest=True)
        return self._helpers[key]

    def lowest(self, name: str, period: int | None = None) -> _StepMonotonic:
        key = f"lowest:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.lowest('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepMonotonic(period, highest=False)
        return self._helpers[key]

    def stoch(self, name: str, period: int | None = None) -> _StepStoch:
        key = f"stoch:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.stoch('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("double", period=period), label=key)
            self._helpers[key] = _StepStoch(period)
        return self._helpers[key]

    def cci(self, name: str, period: int | None = None) -> _StepCCI:
        key = f"cci:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.cci('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("period", period=period), label=key)
            self._helpers[key] = _StepCCI(period)
        return self._helpers[key]

    def hma(self, name: str, period: int | None = None) -> _StepHMA:
        key = f"hma:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.hma('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("hma", period=period), label=key)
            self._helpers[key] = _StepHMA(period)
        return self._helpers[key]

    def barssince(self, name: str) -> _StepBarsSince:
        key = f"barssince:{name}"
        if key not in self._helpers:
            self._helpers[key] = _StepBarsSince()
        return self._helpers[key]

    def valuewhen(self, name: str, occurrence: int | None = None) -> _StepValueWhen:
        key = f"valuewhen:{name}"
        if key not in self._helpers:
            if occurrence is None:
                raise ValueError(f"ctx.ta.valuewhen('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("occurrence", occurrence=occurrence), label=key)
            self._helpers[key] = _StepValueWhen(occurrence)
        return self._helpers[key]

    def crossover(self, name: str) -> _StepCross:
        return self._cross(name, "over")

    def crossunder(self, name: str) -> _StepCross:
        return self._cross(name, "under")

    def cross(self, name: str) -> _StepCross:
        return self._cross(name, "either")

    def _cross(self, name: str, direction: str) -> _StepCross:
        key = f"cross:{direction}:{name}"
        if key not in self._helpers:
            self._helpers[key] = _StepCross(direction)
        return self._helpers[key]

    def vwap(self, name: str) -> _StepVWAP:
        key = f"vwap:{name}"
        if key not in self._helpers:
            self._helpers[key] = _StepVWAP()
        return self._helpers[key]

    def dmi(
        self,
        name: str,
        period: int | None = None,
        adx_period: int = 14,
    ) -> _StepDMI:
        key = f"dmi:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.dmi('{name}') has not been initialized")
            self._helpers[key] = _StepDMI(period, adx_period)
        return self._helpers[key]

    def adx(
        self,
        name: str,
        period: int | None = None,
        adx_period: int | None = None,
    ) -> _StepADX:
        key = f"adx:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.adx('{name}') has not been initialized")
            self._helpers[key] = _StepADX(period, period if adx_period is None else adx_period)
        return self._helpers[key]

    def sar(
        self,
        name: str,
        start: float | None = None,
        increment: float = 0.02,
        maximum: float = 0.2,
    ) -> _StepSAR:
        key = f"sar:{name}"
        if key not in self._helpers:
            if start is None:
                raise ValueError(f"ctx.ta.sar('{name}') has not been initialized")
            self._limits.reserve_window(4, label=key)
            self._helpers[key] = _StepSAR(start, increment, maximum)
        return self._helpers[key]

    def mfi(self, name: str, period: int | None = None) -> _StepMFI:
        key = f"mfi:{name}"
        if key not in self._helpers:
            if period is None:
                raise ValueError(f"ctx.ta.mfi('{name}') has not been initialized")
            self._limits.reserve_window(window_capacity("double", period=period), label=key)
            self._helpers[key] = _StepMFI(period)
        return self._helpers[key]

    def supertrend(
        self,
        name: str,
        factor: float | None = None,
        atr_period: int = 10,
    ) -> _StepSupertrend:
        key = f"supertrend:{name}"
        if key not in self._helpers:
            if factor is None:
                raise ValueError(f"ctx.ta.supertrend('{name}') has not been initialized")
            self._helpers[key] = _StepSupertrend(factor, atr_period)
        return self._helpers[key]

    def pivot_point_levels(
        self,
        name: str,
        pivot_type: str | None = None,
        *,
        developing: bool = False,
    ) -> _StepPivotPointLevels:
        key = f"pivot_point_levels:{name}"
        if key not in self._helpers:
            if pivot_type is None:
                raise ValueError(
                    f"ctx.ta.pivot_point_levels('{name}') has not been initialized"
                )
            self._helpers[key] = _StepPivotPointLevels(
                pivot_type,
                developing=developing,
            )
        return self._helpers[key]

def _rsi_from_avgs(avg_gain: float, avg_loss: float) -> float:
    if avg_loss == 0:
        return 100.0
    if avg_gain == 0:
        return 0.0
    rs = avg_gain / avg_loss
    return 100.0 - 100.0 / (1.0 + rs)


def _number_or_none(value: Any) -> float | None:
    if value is None:
        return None
    number = float(value)
    return None if math.isnan(number) else number


def _nan(value: float | None) -> float:
    return math.nan if value is None else float(value)


def _optional_levels(values: Any) -> tuple[float | None, ...]:
    return tuple(
        None if not math.isfinite(float(value)) else float(value)
        for value in values
    )
